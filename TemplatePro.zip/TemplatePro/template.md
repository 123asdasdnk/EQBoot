
## 个人信息
* 姓 名：叶思成
* 性 别：男&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;年 龄：20
* 手 机：18720566790 &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&ensp;邮 箱：m18720566790@163.com
* 专 业：计算机科学与技术 &emsp;&emsp;&emsp;&emsp;&emsp; 岗 位：Java后端开发

## 教育经历

* 华东交通大学&emsp;&emsp;&emsp;&emsp;&emsp;2022.9~至今&emsp;&emsp;&emsp;&emsp; 计算机科学与技术-本科生
* GPA: 3.76 (24/150)
* 主修课程: 数据结构(95)、操作系统(95)、数据库(90)、计算机网络(84)、计算机组成原理(81)

## 专业技能

* 熟练使用 Java，了解 Python、C、C++、PHP、C# 等编程语言
* 熟练使用SpringBoot，Mybatis-plus，SpringSecurity等框架进行快速开发
* 掌握Redis，Docker，Git，RabbitMQ等中间件的使用
* 掌握Spring Cloud，Spring Cloud Alibaba等微服务框架的使用
* 掌握基础数据结构和算法的基本原理
* 掌握Html，CSS，JS等前端技术的使用，了解Vue, Electron等前端框架
* 了解计算机网络，操作系统，数据库的基本内容

## 项目经历

1. 学校 - 个人待办助手 - 独立开发 - 202501- 202502
   * 前后端分离
   * 技术栈: 前端: HTML+CSS+JS 后端: SpringBoot+SpringSecurity+JWT+Mysql+Redis+Mybatis-plus+RabbitMQ
   * 项目使用Jwt令牌实现用户身份验证并使用MD5对密码进行签名,以及使用Redis缓存对JWT进行缓存
   * 使用Redis对近七天任务以及其它热点数据进行缓存，提高数据库的读写能力
   * 使用RabbitMQ,结合Email模块进行邮箱验证码的发送，提高并发能力,以及使用Redis实现验证码的缓存
   
2. 学校 - 个人博客以及博客管理后台 - 独立开发 - 202409- 202411
    * 前后端分离
    * 技术栈: 前台前端: HTML+CSS+JS，后台前端LayUIAdmin， 后端: SpringBoot+Mybatis+Mysql+Redis
    * 项目使用Jwt令牌实现用户身份验证并使用MD5对密码进行签名
    * 使用Redis缓存对热点文章进行缓存，以及使用Redis实现Jwt的黑名单效果

## 获奖经历
*  2023-2024学年二等奖学金
*  2023校级双基竞赛二等奖
*  2022-2023学年二等奖学金

## 个人账号
* blog 地址:  https://123asdasdnk.github.io/
* github 地址: https://github.com/123asdasdnk


