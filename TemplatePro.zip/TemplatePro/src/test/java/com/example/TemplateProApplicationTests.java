package com.example;


import com.example.entity.dto.AccountDTO;
import com.example.entity.vo.request.AccountReqVO;
import com.example.utils.BeanUtils;
import jakarta.annotation.Resource;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Date;
import java.util.Map;


@SpringBootTest
class TemplateProApplicationTests {

    @Resource
    BeanUtils beanUtils;

    @Test
    void publisher() { //生产者推送消息到Exchange



    }
}
