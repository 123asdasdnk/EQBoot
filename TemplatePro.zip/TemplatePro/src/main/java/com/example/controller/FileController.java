package com.example.controller;

import com.example.entity.RestBean;
import com.example.file.QiniuService;
import jakarta.annotation.Resource;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;

@RestController
@RequestMapping("/api/file")
@ConditionalOnBean(value = QiniuService.class) // 条件注解，只有QiniuService被注册时时，才会注册FileUploadController类
public class FileController {

    @Resource
    private QiniuService qiniuService;

    @PostMapping("/upload")
    public RestBean<String> uploadFile(@RequestParam("file") MultipartFile file) { //上传文件到七牛云，并返回对应的链接
        try {
            return RestBean.success(qiniuService.uploadFile(file));
        } catch (Exception e) {
            e.printStackTrace();
            return RestBean.failure("上传失败");
        }
    }
}