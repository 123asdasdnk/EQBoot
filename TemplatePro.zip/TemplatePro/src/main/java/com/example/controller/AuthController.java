package com.example.controller;

import com.example.entity.RestBean;
import com.example.service.AccountService;
import com.example.utils.VerifyCodeUtils;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
public class AuthController { //认证模块(无需token)
    @Resource
    AccountService service;

    @Resource
    VerifyCodeUtils verifyCodeUtils;

    //注册账户
    @PostMapping("/registerAccount")
    public RestBean<String> registerAccount(String username, String password, String email, String verifyCode){
//        System.out.println(username + " " + password + "  "+ email + " " + verifyCode);
        String exists = verifyCodeUtils.isCodeExists(verifyCode, email);
        if(!exists.equals("验证码正确")){
            return RestBean.failure(exists);
        }
        if(service.checkUsername(username) != null){
            return RestBean.failure("用户名已存在");
        }
        if(service.checkEmail(email) != null){
            return RestBean.failure("邮箱已被注册");
        }
        Boolean res = service.registerAccount(username, password, email);
        verifyCodeUtils.deleteCode(verifyCode); //验证成功记得把验证码从redis里面删除
        return res ? RestBean.success("注册成功") : RestBean.failure("注册失败");
    }

    @PostMapping("/resetPassword")
    public RestBean<String> resetPassword(String email, String newPassword, String verifyCode){
        String exists = verifyCodeUtils.isCodeExists(verifyCode, email);
        if(!exists.equals("验证码正确")){
            return RestBean.failure(exists);
        }
        String res = service.resetPassword(email, newPassword);
        if(res.equals("密码重置成功")){
            verifyCodeUtils.deleteCode(verifyCode);//记得删除验证码
            return RestBean.success(res);
        }else {
            return RestBean.failure(res);
        }

    }
}
