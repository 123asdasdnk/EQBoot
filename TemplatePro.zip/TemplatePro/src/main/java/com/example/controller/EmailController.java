package com.example.controller;

import com.example.entity.RestBean;
import com.example.mq.RabbitConst;
import com.example.mq.publish.Publisher;
import com.example.utils.EmailUtils;
import com.example.utils.VerifyCodeUtils;
import jakarta.annotation.Resource;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth/email")
public class EmailController { //邮件模块(无需token)
    @Resource
    EmailUtils emailUtils;

    @Resource
    RabbitTemplate rabbitTemplate;

    @Resource
    VerifyCodeUtils verifyCodeUtils;

    //发送验证码
    @PostMapping("/sendVerifyCode")
    public RestBean<String> senderVerifyCode(String email){
//        System.out.println("验证码发送到: " + email);
        if(email == null) return RestBean.failure("邮箱不能为空");
        boolean res = emailUtils.sendCode(email, verifyCodeUtils.createVerifyCode());
        return res ? RestBean.success("验证码发送成功") : RestBean.failure("验证码发送失败,请检测邮箱格式");
    }

    //通过RabbitMQ发送验证码
    @PostMapping("/sendVerifyCodeByMQ")
    public RestBean<String> senderVerifyCodeByMQ(String email){
        System.out.println("验证码发送到: " + email);
        if(email == null) return RestBean.failure("邮箱不能为空");
        Publisher publisher = new Publisher();
        publisher.publish(rabbitTemplate, RabbitConst.TOPIC_EXCHANGE, RabbitConst.TOPTIC_RoutingKey_TWO, email);
        return RestBean.success("验证码发送成功");
    }

    //检查验证码是否正确
    @GetMapping("/checkVerifyCode") //接口暂时没有用到
    public RestBean<String> checkVerifyCode(String verifyCode, String email){
        String exists = verifyCodeUtils.isCodeExists(verifyCode, email);
        if(exists.equals("验证码正确")){
            return RestBean.success(exists);
        }else {
            return RestBean.failure(exists);
        }
    }

}
