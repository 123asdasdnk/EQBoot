package com.example.controller;

import com.example.entity.RestBean;
import com.example.entity.dto.AccountDTO;
import com.example.service.AccountService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/account")
public class AccountController { //用户数据模块(需要token)
    @Resource
    AccountService service;

    @GetMapping("/getLoginAccount")
    public RestBean<AccountDTO> getLoginAccount(String username){
        AccountDTO accountDTO = service.findAccountByNameOrEmail(username);
        return RestBean.success(accountDTO);
    }

    @PostMapping("/updateAccountInfoByUsername")
    public RestBean<String> updateAccountInfoByUsername(String username, String nickname, String avatar_url, String email){
        Boolean result = service.updateAccountInfoByUsername(username, nickname, avatar_url, email);
        return result ? RestBean.success("更新成功") : RestBean.failure("更新失败");
    }
}
