package com.example.utils;

public class Const { //常量类
    public static String JWT_BLACK_LIST = "jwt:blacklist:"; //jwt黑名单

    public static final String HOT_ARTICLE_LIST = "hot:articles:"; //热点文章
    // 邮箱格式验证正则表达式（不区分大小写）
    public static final String EMAIL_REGEX =
            "^(?i)" + // 开启不区分大小写
                    "[a-zA-Z0-9]" + // 首字符必须是字母或数字
                    "(?:[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]{0,30}[a-zA-Z0-9])?" + // 中间可包含特殊字符
                    "@" +
                    "(?:" +
                    // 国内常用邮箱服务商
                    "(?:qq|163|126|yeah|vip\\.163|vip\\.qq|foxmail)\\.(?:com|net)" +
                    "|" +
                    // 国际常用邮箱服务商
                    "(?:gmail|outlook|hotmail|icloud|protonmail|yahoo|aol|zoho|mail)\\.(?:com|net|me)" +
                    "|" +
                    // 企业邮箱域名验证（示例）
                    "(?:公司自定义域名)\\.(?:com|cn|net)" +
                    ")$";

    // RFC5322 标准邮箱验证
    public static final String RFC5322_EMAIL_REGEX =
            "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+" +
                    "@" +
                    "[a-zA-Z0-9.-]+$";
}
