package com.example.utils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Component
public class JwtUtils {

    @Value("${spring.security.jwt.key}")
    String key; //加密密钥

    @Value("${spring.security.jwt.expire}")
    int expire; //过期时间

    @Resource
    StringRedisTemplate template;

    public boolean invalidateJwt(String headerToken){
        String token = this.convertToken(headerToken); //这里的token是去掉Bearer的
        if(token == null) return false; //如果解析出来为null(不合法)直接返回false即可
        Algorithm algorithm = Algorithm.HMAC256(key);
        JWTVerifier jwtVerifier = JWT.require(algorithm).build();//创建jwt验证器
        try{
            DecodedJWT jwt = jwtVerifier.verify(token);
            String id = jwt.getId();
            return deleteToken(id, jwt.getExpiresAt());
        }catch (JWTVerificationException e){
            return false; //如果抛出异常了，也返回null
        }
    }

    private boolean deleteToken(String uuid, Date time){
        if(this.isInvalidToken(uuid))
            return false;
        Date now = new Date();
        long expire = Math.max(time.getTime() - now.getTime(), 0);
        template.opsForValue().set(Const.JWT_BLACK_LIST + uuid, "", expire, TimeUnit.MILLISECONDS);
        return true;
    }

    //判断令牌是否失效
    private boolean isInvalidToken(String uuid){
        return Boolean.TRUE.equals(template.hasKey(Const.JWT_BLACK_LIST + uuid));
    }

    //解析jwt
    public DecodedJWT resolveJwt(String headerToken){ //headerToken是困可能携带了请求头Bearer的
        String token = this.convertToken(headerToken); //这里的token是去掉Bearer的
        if(token == null) return null; //如果解析出来为null(不合法)直接返回null即可
        //如果合法，就用原来的加密算法解析出来
        Algorithm algorithm = Algorithm.HMAC256(key);
        JWTVerifier jwtVerifier = JWT.require(algorithm).build();//创建jwt验证器
        try{
            DecodedJWT jwt = jwtVerifier.verify(token); //解析jwt,并验证jwt是否被篡改过，是的话，会抛出一个异常
            if(this.isInvalidToken(jwt.getId()))
                return null;
            Date expiresAt = jwt.getExpiresAt(); //解析出来jwt后还要对其进行过期判断
            return new Date().after(expiresAt) ? null : jwt; //没有过期就返回jwt,过期还是null
        }catch (JWTVerificationException e){
            return null; //如果抛出异常了，也返回null
        }
    }

    //创建jwt令牌
    public String createJwt(UserDetails details, int id, String username){ //参数是UserDetails可以获取当前登录用户的信息
        Algorithm algorithm = Algorithm.HMAC256(key);
        Date expire = this.expireTime();
        return JWT.create() //创建令牌
                .withJWTId(UUID.randomUUID().toString())
                .withClaim("id", id)
                .withClaim("Username", username)
                .withClaim("authorities", details.getAuthorities().stream().map(GrantedAuthority::getAuthority).toList())
                .withExpiresAt(expire) //设置过期时间
                .withIssuedAt(new Date()) //设置颁发时间
                .sign(algorithm);
    }

    //判断token是否合法(是否不为空，且携带bearer)
    private String convertToken(String headerToken){
        if(headerToken == null || !headerToken.startsWith("Bearer ")){ //如果为空或者不是以bearer开头，所以不合法，返回null即可
            return null;
        }else {
            return headerToken.substring(7); //合法，就取掉前面的Bearer ,然后返回后面的即可
        }
    }

    //将用户信息，从jwt中解析出来
    public UserDetails toUser(DecodedJWT jwt){
        Map<String, Claim> claims = jwt.getClaims();
        return User
                .withUsername(claims.get("Username").asString())
                .password("*******") //这里随便写不重要，不可以把密码放到jwt里面哦
                .authorities(claims.get("authorities").asArray(String.class))
                .build();
    }

    public Integer toId(DecodedJWT jwt) {
        Map<String, Claim> claims = jwt.getClaims();
        return claims.get("id").asInt();
    }

    //计算过期时间
    public Date expireTime(){
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.HOUR, expire * 24);
        return calendar.getTime();
    }
}
