package com.example.utils;

import com.example.entity.vo.response.VerifyCodeRespVO;
import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

@Component
public class EmailUtils { //邮件模块

    @Resource
    JavaMailSender sender;

    @Resource
    VerifyCodeUtils verifyCodeUtils;

    @Value("${spring.code.codeExpire}")
    int codeExpire;

    @Value("${spring.code.senderEmail}")
    String senderEmail;

    @Value("${spring.project.name}")
    String projectName;

    //发送验证码
    public boolean sendCode(String email, VerifyCodeRespVO verifyCodeRespVO){
        //检查邮箱格式是是否为合法邮箱(有两种检验策略，见Const类)
        if(!email.matches(Const.EMAIL_REGEX)){
            return false;
        }
        //SimpleMailMessage是一个比较简易的邮件封装，支持设置一些比较简单内容
        SimpleMailMessage message = new SimpleMailMessage();
        //设置邮件标题
        message.setSubject(projectName +" : 验证码");
        //设置邮件内容
        message.setText("验证码为: " + verifyCodeRespVO.getCode() + " 有效期为: " + codeExpire + "分钟");
        //设置邮件发送给谁，可以多个，这里就发给你的QQ邮箱
        message.setTo(email);
        //邮件发送者，这里要与配置文件中的保持一致
        message.setFrom(senderEmail);
        sender.send(message);
        verifyCodeUtils.saveCode(verifyCodeRespVO, email); //发送完了之后，记得把验证码存储到redis里面(验证码为键，值为对应的邮箱)
        return true;
    }

    //发送文本
    public void sendText(String email, String text){
        // TODO 发送文本邮件
    }
}
