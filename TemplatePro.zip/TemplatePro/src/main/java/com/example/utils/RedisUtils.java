package com.example.utils;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

@Component
public class RedisUtils { //Redis工具模块
//    @Resource
//    private RedisTemplate<String, Object> redisTemplate;

    @Resource
    StringRedisTemplate stringRedisTemplate;

    @Value("${spring.data.redis.hotDataExpire}")
    int hotDataExpire;

    private static final Logger logger = LoggerFactory.getLogger(RedisUtils.class);

    @PostConstruct
    public void init() {
        logger.info("Redis工具类正在加载...");
    }

    /**
     * 保存对象到 Redis
     * @param key   键
     * @param value 值（对象）
     */
    public void saveObject(String key, String value) { //保存键值对
//        redisTemplate.opsForValue().set(key, value);
        stringRedisTemplate.opsForValue().set(key, value, hotDataExpire, TimeUnit.MINUTES);
    }

    /**
     * 从 Redis 读取对象
     * @param key 键
     * @return 对象
     */
    public String getObject(String key) { //获取键值
        return stringRedisTemplate.opsForValue().get(key);
    }

    /**
     * 从Redis删除指定对象
     * @param key
     * @return
     */
    public boolean removeKey(String key){ //删除键值
        return Boolean.TRUE.equals(stringRedisTemplate.delete(key));
    }

    /**
     * 获取前缀符合pattern的key
     * @param pattern
     * @return 对应的set
     */
    public Set<String> getHotDataList(String pattern){
        return stringRedisTemplate.keys(pattern);
    }

    /**
     *  将Set变成List
     * @param hotDataSet
     * @return
     */
    public List<String> getDataKeyList(Set<String> hotDataSet){
        List<String> keyList = new ArrayList<>();
        Iterator it = hotDataSet.iterator();
        while (it.hasNext()) {
            String str = (String) it.next();
            keyList.add(str);
        }
        return keyList;
    }




}
