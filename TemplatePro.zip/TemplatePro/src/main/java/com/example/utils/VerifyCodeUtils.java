package com.example.utils;


import com.example.entity.vo.response.VerifyCodeRespVO;
import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.concurrent.TimeUnit;

@Component
public class VerifyCodeUtils { //验证码模块

    @Value("${spring.code.codeLength}")
    int codeLength; //验证码长度为数字个数

    @Value("${spring.code.codeExpire}")
    int codeExpire; //时间(分钟数)

    @Resource
    StringRedisTemplate template;

    public VerifyCodeRespVO createVerifyCode(){
        StringBuilder code = new StringBuilder();
        for (int i = 0; i < codeLength; i++) { //生成5位数字验证码
            int num = (int) (Math.random() * 9) + 1;
            code.append(num);
        }
        String verifyCode = code.toString();
//        System.out.println("获取到的验证码为:"+verifyCode);
        VerifyCodeRespVO verifyCodeRespVO = new VerifyCodeRespVO();
        verifyCodeRespVO.setCode(verifyCode); //设置验证码
        verifyCodeRespVO.setIssuedAt(new Date()); //设置颁发时间
        return verifyCodeRespVO;
    }

    // 创建验证码之后，等到发送给客户的时候，就把验证码存储到redis中(记得做一个过期时间)
    // 等到注册，验证验证码的时候，就先取出来，
    // 如果不存在，就验证失败，说明验证码过期或者不存在，因为会我们这里设置了过期时间的，5分钟之后自动删除，
    // 如果存在，验证成功，并且把验证码从redis中删了，

    //验证码是否存在，用于验证码校验
    public String isCodeExists(String verifyCode, String email){
        try {
            // 1. 检查验证码是否存在
            String storedEmail = template.opsForValue().get(verifyCode);
            if (storedEmail == null) {
                return "验证码不存在或已过期"; // 验证码不存在或已过期
            }
            // 2. 验证邮箱是否匹配
            return storedEmail.equalsIgnoreCase(email) ? "验证码正确" : "验证码与邮箱不匹配"; // 忽略大小写匹配邮箱
        } catch (Exception e) {
            // 处理可能的Redis连接异常等情况
            e.printStackTrace();
            return "数据库连接出错，请重试!!!"; // 出现异常时视为验证失败
        }
    }

    //保存验证码到redis
    public void saveCode(VerifyCodeRespVO verifyCodeRespVO, String email){
        template.opsForValue().set(verifyCodeRespVO.getCode(), email, codeExpire, TimeUnit.MINUTES); //直接把验证码作为key存储到redis里面,value可以不存，然后设定过期时间为5分钟，
    }

    //删除redis中对应的验证码
    public void deleteCode(String verifyCode){
        template.delete(verifyCode);
    }

    //计算过期时间
    public Date expireTime(){
        return new Date(System.currentTimeMillis() + (codeExpire * 60000)); //当前时间加上过期时间的毫秒数
    }

}
