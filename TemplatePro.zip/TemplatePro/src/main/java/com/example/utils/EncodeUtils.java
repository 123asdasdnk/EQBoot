package com.example.utils;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class EncodeUtils { //加密工具类

    //加密密码
    public String encode(String code){ //加密密码
        return new BCryptPasswordEncoder().encode(code);
    }

    //验证密码
    public boolean match(String password, String storedPassword){ //校验给定密码(明码)和数据库中存储(加密)的是否相同
        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
        return bCryptPasswordEncoder.matches(password, storedPassword);
    }

}
