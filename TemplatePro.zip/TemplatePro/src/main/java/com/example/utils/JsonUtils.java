package com.example.utils;

import com.alibaba.fastjson2.JSON;
import org.springframework.stereotype.Component;

@Component
public class JsonUtils { //Json字符串处理器

    /**
     * 将对象变成JSON格式
     * @param object
     * @return
     */
    public String ObjectToJson(Object object){
        return JSON.toJSONString(object);
    }

    /**
     *  Json字符串变成Object对象
     * @param jsonStr
     * @param object
     * @return
     */

    public Object JsonToObject(String jsonStr, Object object){
        return JSON.parseObject(jsonStr, object.getClass());
    }
}
