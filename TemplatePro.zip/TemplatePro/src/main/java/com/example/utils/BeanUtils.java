package com.example.utils;


import cn.hutool.core.bean.BeanUtil;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class BeanUtils { // (对象转化工具类) 使用hutool工具类实现BeanUtils的功能


    public <T> T copyProperties(Object source, Class<T> targetClass) {
        return BeanUtil.copyProperties(source, targetClass);
    }

    // 复制属性
    public void copyProperties(Object source, Object target) {
        BeanUtil.copyProperties(source, target);
    }

    // 对象转Map
    public Map<String, Object> beanToMap(Object bean) {
        return BeanUtil.beanToMap(bean);
    }

    // 将VO转换为DTO
    public <D, V> D voToDto(V vo, Class<D> dtoClass) {
        return copyProperties(vo, dtoClass);
    }

    // 将DTO转换为VO
    public <V, D> V dtoToVo(D dto, Class<V> voClass) {
        return copyProperties(dto, voClass);
    }
}

