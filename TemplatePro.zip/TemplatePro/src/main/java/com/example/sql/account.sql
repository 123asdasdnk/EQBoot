-- 这是用户表，一定要先把这个sql语句先执行

create table db_account
(
    id            int auto_increment
        primary key,
    username      varchar(255)                 null,
    password      varchar(255)                 null,
    nickname      varchar(255) default 'hello' null,
    email         varchar(255)                 null,
    role          varchar(255) default 'user'  null,
    register_time datetime                     null,
    status        varchar(255) default '否'    null,
    avatar_url    longtext                     null,
    constraint email
        unique (email),
    constraint username
        unique (username)
);

