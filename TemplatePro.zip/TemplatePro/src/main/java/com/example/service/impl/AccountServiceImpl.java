package com.example.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.entity.dto.AccountDTO;
import com.example.mapper.AccountMapper;
import com.example.service.AccountService;
import com.example.utils.EncodeUtils;
import jakarta.annotation.Resource;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class AccountServiceImpl extends ServiceImpl<AccountMapper, AccountDTO> implements AccountService {
    @Resource
    EncodeUtils encodeUtils;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        AccountDTO accountDTO = this.findAccountByNameOrEmail(username);
        if(accountDTO == null)
            throw new UsernameNotFoundException("用户名或密码错误");
        return User
                .withUsername(username)
                .password(accountDTO.getPassword())
                .roles(accountDTO.getRole())
                .build();
    }

    public AccountDTO findAccountByNameOrEmail(String text){
        return this.query()
                .eq("username", text).or()
                .eq("email", text)
                .one();
    }

    @Override
    public Boolean updateAccountInfoByUsername(String username, String nickname, String avatar_url, String email) {
        AccountDTO accountDTO = this.query().eq("username", username).one();
        if (accountDTO == null) {
            return false; // 用户不存在
        }
        accountDTO.setNickname(nickname);
        accountDTO.setAvatar_url(avatar_url);
        accountDTO.setEmail(email);
        return this.updateById(accountDTO);
    }

    //检查用户名是否存在
    @Override
    public AccountDTO checkUsername(String username) {
        return this.query().eq("username", username).one();
    }

    @Override
    public Boolean registerAccount(String username, String password, String email) {
        // 创建 Account 对象，字段为提供的值，其他字段使用默认值
        AccountDTO accountDTO = new AccountDTO(null, username, encodeUtils.encode(password), "hello", email, "user", new Date(), "否", "");
        // 插入数据
        return this.save(accountDTO);
    }

    //检查email是否被注册
    @Override
    public AccountDTO checkEmail(String email) {
        return this.query().eq("email", email).one();
    }

    @Override
    public String resetPassword(String email, String password) {
        AccountDTO accountDTO = this.query().eq("email", email).one();
        if (accountDTO == null) {
            return "用户不存在"; // 用户不存在
        }
        if(encodeUtils.match(password, accountDTO.getPassword())){ //校对新旧密码是否相同
            return "新旧密码不能相同";
        }
        accountDTO.setPassword(encodeUtils.encode(password)); //重置密码
        return this.updateById(accountDTO) ? "密码重置成功" : "密码重置失败";
    }
}
