package com.example.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.entity.dto.AccountDTO;
import org.springframework.security.core.userdetails.UserDetailsService;


public interface AccountService extends IService<AccountDTO>, UserDetailsService {
    AccountDTO findAccountByNameOrEmail(String text);

    Boolean updateAccountInfoByUsername(String username, String nickname, String avatar_url, String email);

    AccountDTO checkUsername(String username);

    Boolean registerAccount(String username, String password, String email);

    AccountDTO checkEmail(String email);

    String resetPassword(String email, String password);
}
