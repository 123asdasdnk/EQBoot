package com.example;


import com.example.system.SystemModuleService;
import jakarta.annotation.Resource;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling //启用定时任务功能
public class TemplateProApplication implements ApplicationRunner {

    @Resource
    private SystemModuleService systemModuleService;

    public static void main(String[] args) {
        SpringApplication.run(TemplateProApplication.class, args);

    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        print(systemModuleService);
    }

    public void print(SystemModuleService systemModuleService) {
        // ANSI 颜色代码
        String RESET = "\u001B[0m"; // 重置颜色
        String GREEN = "\u001B[32m"; // 绿色
        String RED = "\u001B[31m"; // 红色
        String YELLOW = "\u001B[33m"; // 黄色
        String CYAN = "\u001B[36m"; // 青色
        String BLUE = "\u001B[34m"; // 蓝色

        // 分隔线
        String separator = "=============================================================================";

        // 标题
        System.out.println(YELLOW + separator + RESET);
        System.out.println(CYAN + "        🚀 系统模块监控状态报告 🚀" + RESET);
        System.out.println(YELLOW + separator + RESET);

        // 模块状态
        System.out.println("🛠️  AOP模块方法监控状态: [" +
                (systemModuleService.AOP ? GREEN + "✔ 开启" : RED + "✘ 关闭") + RESET + "](推荐开启)");
        System.out.println("🐇  RabbitMQ模块HelloWorld模式状态: [" +
                (systemModuleService.HelloWorld ? GREEN + "✔ 开启" : RED + "✘ 关闭") + RESET + "](可选)");
        System.out.println("📡  RabbitMQ模块Topic模式状态: [" +
                (systemModuleService.Topic ? GREEN + "✔ 开启" : RED + "✘ 关闭") + RESET + "](可选)");
        System.out.println("⏰  定时任务模块默认模式状态: [" +
                (systemModuleService.DefaultTask ? GREEN + "✔ 开启" : RED + "✘ 关闭") + RESET + "](可选)");
        System.out.println("⏳  定时任务模块Quartz模式状态: [" +
                (systemModuleService.QuartzConfiguration ? GREEN + "✔ 开启" : RED + "✘ 关闭") + RESET + "](不推荐开启)");
        System.out.println("🔐  OSS模块七牛云OSS状态 [" +
                (systemModuleService.qiNiuOSS ? GREEN + "✔ 开启" : RED + "✘ 关闭") + RESET + "](可选)");
        // 结尾分隔线
        System.out.println(YELLOW + separator + RESET);

        // 欢迎信息和链接
        System.out.println(BLUE + "🌟 \uD83E\uDD2A 欢迎使用EQBoot，希望给您带来不一样的体验！ (๑•̀ㅂ•́)و✧ \uD83D\uDC7B🌟" + RESET);
        System.out.println(CYAN + "📂 开源地址: " + BLUE + "https://github.com/123asdasdnk/EQBoot" + RESET);
        System.out.println(CYAN + "📚 官方文档: " + BLUE + "https://eqboot.org/docs" + RESET);
        System.out.println(CYAN + "✍️ 博客地址: " + BLUE + "https://123asdasdnk.github.io" + RESET);

        System.out.println(YELLOW + separator + RESET);
    }

}
