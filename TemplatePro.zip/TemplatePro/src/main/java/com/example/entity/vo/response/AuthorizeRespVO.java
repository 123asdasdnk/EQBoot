package com.example.entity.vo.response;

import lombok.Data;

import java.util.Date;

@Data
public class AuthorizeRespVO { //最后响应给前端的实体类
    String username; //用户名
    String role; //角色
    String token; //token
    Date expire; //过期时间
}
