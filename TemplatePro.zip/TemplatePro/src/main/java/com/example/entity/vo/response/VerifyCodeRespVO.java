package com.example.entity.vo.response;

import lombok.Data;

import java.util.Date;

@Data
public class VerifyCodeRespVO {
    String code; //验证码
    Date issuedAt; //验证码创建颁发时间(5分钟内有效)
}
