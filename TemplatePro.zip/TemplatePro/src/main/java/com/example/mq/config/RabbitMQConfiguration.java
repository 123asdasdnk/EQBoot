package com.example.mq.config;

import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfiguration {
    //--------------------转化器------------------------
    @Bean("jacksonConverter")   //直接创建一个用于JSON转换的Bean，这样就可以直接接收一个JSON格式的消息，并且直接获取到实体类
    public Jackson2JsonMessageConverter converter(){
        return new Jackson2JsonMessageConverter();
    }
}
