package com.example.mq.consume;

import com.example.mq.RabbitConst;
import com.example.mq.config.RabbitMQDirectConfig;
import com.example.mq.config.RabbitMQTopicConfig;
import com.example.utils.EmailUtils;
import com.example.utils.VerifyCodeUtils;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnBean(value = RabbitMQTopicConfig.class) // 只要RabbitMQTopicConfig被注册了才注册
public class TopicConsumer<T> {
    @Resource
    EmailUtils emailUtils;

    @Resource
    VerifyCodeUtils verifyCodeUtils;

    private static final Logger logger = LoggerFactory.getLogger(DirectConsumer.class);
    @PostConstruct
    public void init() {
        logger.info("TopicConsumer初始化完成");
    }

    @RabbitListener(queues = RabbitConst.TOPIC_QUEUE_ONE, messageConverter = "jacksonConverter") //本消费者，关联队列Queue1,只要exchange里面有消息就会通过channel到达队列，然后会被本消费者自动消费
    public void getTopicQueueMessage(T message){
        System.out.println("TopicConsumer接收到消息:" + message);
    }

    @RabbitListener(queues = RabbitConst.TOPIC_QUEUE_TWO, messageConverter = "jacksonConverter")
    public void SendEmail(String email){
        try {
            System.out.println("接收到发送验证码请求");
            emailUtils.sendCode(email, verifyCodeUtils.createVerifyCode());
            System.out.println("发送完成");
        } catch (Exception e) {
            System.err.println("发送验证码失败: " + e.getMessage());
            // 记录异常或进行其他处理
        }

    }
}