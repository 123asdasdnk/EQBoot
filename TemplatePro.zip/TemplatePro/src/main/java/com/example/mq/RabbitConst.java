package com.example.mq;

public class RabbitConst { //定义各种MQ常量
    //注意:之后写配置的时候，一个队列对应一个RoutingKey,一个消费者对应一个队列,比如，如果是发送邮件的队列就只绑定*.email.*，不要出现一个队列里面有多种不同的消息类型
    //

    // Topic模式用通配符，进行编写RoutingKey(hello world模式不可以，只能写字符串)
    //    * - 表示任意的一个单词 如: *.email.#
    //    # - 表示0个或多个单词

    //各种RoutingKey的值
    public final static String DIRECT_RoutingKey_ONE = "Key1";

    public final static String DIRECT_RoutingKey_TWO = "Key2";

    public final static String TOPTIC_RoutingKey_ONE = "Key1";

    public final static String TOPTIC_RoutingKey_TWO = "*.email.*";

    // TODO 更多RoutingKey可根据需要进行添加...


    //hello world模式
    public final static String DIRECT_EXCHANGE = "direct.exchange"; //普通交换机
    public final static String DIRECT_QUEUE = "direct.queue"; //普通队列

    //Topic模式
    public final static String TOPIC_EXCHANGE = "topic.exchange"; //主题交换机
    public final static String TOPIC_QUEUE_ONE = "topic.queue1"; //主题队列1
    public final static String TOPIC_QUEUE_TWO = "topic.queue2"; //主题队列2

    // TODO 更多通讯模式可根据需要进行添加...

}
