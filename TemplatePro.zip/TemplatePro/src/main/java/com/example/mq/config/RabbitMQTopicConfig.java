package com.example.mq.config;

import com.example.mq.RabbitConst;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConditionalOnProperty(prefix = "system.modules.MQ.RabbitMQ", name = "Topic", havingValue = "true") //根据配置文件来判断是否加载Topic模式
public class RabbitMQTopicConfig {

    private static final Logger logger = LoggerFactory.getLogger(RabbitMQDirectConfig.class);

    @PostConstruct
    public void init(){
        logger.info("MQ: Topic 模式已经被加载");
    }

    //-------------------topic模式---------------------------
    //1.创建topic交换机
    @Bean("topicExchange")
    public TopicExchange getTopicExchange(){
        return new TopicExchange(RabbitConst.TOPIC_EXCHANGE, true, false);
    }
    //2.创建队列
    //创建第一个队列
    @Bean("topicQueue1")
    public Queue getTopicQueue1(){
        return new Queue(RabbitConst.TOPIC_QUEUE_ONE, true, false, false, null);
    }
    //创建第二个队列
    @Bean("topicQueue2")
    public Queue getTopicQueue2(){
        return new Queue(RabbitConst.TOPIC_QUEUE_TWO, true, false, false, null);
    }

    //3.将队列和交换机绑定在一起
    //将第一个队列与topic交换机绑定在一起
    @Bean("directBinding_ONE")
    public Binding getTopicBinding_ONE(@Qualifier("topicExchange")TopicExchange topicExchange,
                                       @Qualifier("topicQueue1") Queue queue){ //这种参数是在Bean中的会自动去IOC里面找
        return BindingBuilder.bind(queue).to(topicExchange).with(RabbitConst.TOPTIC_RoutingKey_ONE); //路由规则是RabbitConst.TOPTIC_RoutingKey_ONE
    }

    //将第二个队列与topic交换机绑定在一起
    @Bean("directBinding_TWO")
    public Binding getTopicBinding_TWO(@Qualifier("topicExchange")TopicExchange topicExchange,
                                       @Qualifier("topicQueue2") Queue queue){ //这种参数是在Bean中的会自动去IOC里面找
        return BindingBuilder.bind(queue).to(topicExchange).with(RabbitConst.TOPTIC_RoutingKey_TWO); //路由规则是RabbitConst.TOPTIC_RoutingKey_TWO
    }


}
