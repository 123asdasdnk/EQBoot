package com.example.mq.consume;

import com.example.mq.RabbitConst;
import com.example.mq.config.RabbitMQDirectConfig;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnBean(value = RabbitMQDirectConfig.class) // 只要RabbitMQDirectConfig被注册了才注册
public class DirectConsumer<T> {

    private static final Logger logger = LoggerFactory.getLogger(DirectConsumer.class);
    @PostConstruct
    public void init() {
        logger.info("DirectConsumer初始化完成");
    }

    //消费者要使用@RabbitListener(queues = "队列名", messageConverter = "json转化器")来指定监听某个队列
    @RabbitListener(queues = RabbitConst.DIRECT_QUEUE, messageConverter = "jacksonConverter") //本消费者，关联队列Queue1,只要exchange里面有消息就会通过channel到达队列，然后会被本消费者自动消费
    public void getDirectQueueMessage(T message){

        System.out.println("DirectConsumer接收到消息:" + message);
    }
}
