package com.example.mq.config;

import com.example.mq.RabbitConst;

import jakarta.annotation.PostConstruct;
import org.springframework.amqp.core.*;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Configuration
@ConditionalOnProperty(prefix = "system.modules.MQ.RabbitMQ", name = "HelloWorld", havingValue = "true") //根据配置文件来判断是否加载HelloWorld模式
public class RabbitMQDirectConfig {
    private static final Logger logger = LoggerFactory.getLogger(RabbitMQDirectConfig.class);

    @PostConstruct
    public void init(){
        logger.info("MQ: Hello world 模式已经被加载");
    }

    //--------------hello world模式---------------------
    //1.创建普通交换机
    @Bean("directExchange")  //定义交换机Bean，可以很多个(根据Bean名称来区分)
    public Exchange getExchange(){ //创建一个类型为 Direct 的交换机，名称为 exchange1。对应的Bean名称为directExchange
        return ExchangeBuilder.directExchange(RabbitConst.DIRECT_EXCHANGE).build();
        //使用ExchangeBuilder.directExchange("交换机的名称").build()来创建一个交换机
    }

    //@Bean("directExchange")：定义一个名为 directExchange 的 Bean，表示这是一个交换机。
    //ExchangeBuilder.directExchange(RabbitConst.DIRECT_EXCHANGE)：创建一个类型为 Direct 的交换机，名称为 RabbitConst.DIRECT_EXCHANGE常量。
    // Direct 交换机会根据 routing key 将消息路由到绑定的队列。

    //2.创建普通队列
    @Bean("directQueue")     //定义队列Bean，可以很多个(根据Bean名称来区分)
    public Queue queue(){
        return QueueBuilder
                .nonDurable(RabbitConst.DIRECT_QUEUE)   //非持久化类型
                .build();
    }
    //定义一个名为 Queue 的 Bean，表示这是一个消息队列。
    //QueueBuilder.nonDurable("queue1")：创建一个非持久化的队列，名称为 queue1。非持久化队列在 RabbitMQ 重启后不会保留

    //3.将普通队列和交换机绑定在一起
    @Bean("directBinding")
    public Binding directBinding(@Qualifier("directExchange") Exchange exchange,
                           @Qualifier("directQueue") Queue queue){ //@Qualifier("Bean名称")会找到对应名称的bean赋值给后面的参数
        //将我们刚刚定义的交换机和队列进行绑定(中间其实还是会有一个channel的)
        return BindingBuilder
                .bind(queue)   //绑定队列
                .to(exchange)  //到交换机
                .with(RabbitConst.DIRECT_RoutingKey_ONE)   //使用自定义的routingKey
                .noargs();
    }
    //@Bean("directBinding")：定义一个名为 directBinding 的 Bean，表示这是一个绑定关系。
    //@Qualifier("directExchange") 和 @Qualifier("directQueue")：通过 @Qualifier 注解来注入之前定义的交换机和队列 Bean。
    //BindingBuilder.bind(queue)：开始绑定队列。
    //.to(exchange)：指定要绑定的交换机。
    //.with(RabbitConst.DIRECT_RoutingKey_ONE)：指定 routing key 为 DIRECT_RoutingKey_ONE常量，这意味着只有 routing key 为 RabbitConst.DIRECT_RoutingKey_ONE 的消息会被路由到这个队列。
    //.noargs()：表示没有额外的参数。
}
