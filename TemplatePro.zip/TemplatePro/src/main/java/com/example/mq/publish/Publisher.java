package com.example.mq.publish;

import org.springframework.amqp.rabbit.core.RabbitTemplate;

public class Publisher { //推送消息

    public boolean publish(RabbitTemplate rabbitTemplate, String exchange, String routingKey, Object msg){
        rabbitTemplate.convertAndSend(exchange, routingKey, msg);
        return true;
    }

}
