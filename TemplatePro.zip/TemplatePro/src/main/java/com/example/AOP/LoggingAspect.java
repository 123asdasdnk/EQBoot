package com.example.AOP;

import jakarta.annotation.PostConstruct;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Aspect //开启AOP支持
@Component
@ConditionalOnProperty(prefix = "system.modules", name = "AOP", havingValue = "true") //根据条件来判断是否注册A
public class LoggingAspect { //用于监控各种方法的调用

    private static final Logger logger = LoggerFactory.getLogger(LoggingAspect.class);

    // 定义一个切点，匹配 com.example.service 包及其子包下的所有方法
    // 使用 @PostConstruct 注解标注该方法应在 bean 初始化之后执行
    @PostConstruct
    public void init(){
        logger.info("Controller方法监控已开启...");
    }

    // 定义一个切点，匹配 com.example.controller 包及其子包下的所有方法
    @Pointcut("within(com.example.controller..*)")
    public void controllerMethods() {}

    // @Before 注解表示在目标方法执行之前执行该方法
    @Before("controllerMethods()")
    public void beforeController(JoinPoint joinPoint) {
        logger.info("======================方法监控=============================");
        logger.info("调用方法: " + joinPoint.getSignature().getName());
        logger.info("参数: " + Arrays.toString(joinPoint.getArgs()));
    }

    // @AfterReturning 注解表示在目标方法成功返回结果之后执行该方法
    @AfterReturning(pointcut = "controllerMethods()", returning = "result")
    public void afterReturningController(JoinPoint joinPoint, Object result) {
        logger.info("方法返回结果: " + result);
    }

    // @AfterThrowing 注解表示在目标方法抛出异常后执行该方法
    @AfterThrowing(pointcut = "controllerMethods()", throwing = "error")
    public void afterThrowingController(JoinPoint joinPoint, Throwable error) {
        logger.error("方法抛出异常: " + error);
    }

}
