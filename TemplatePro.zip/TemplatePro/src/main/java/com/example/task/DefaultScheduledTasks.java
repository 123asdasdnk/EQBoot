package com.example.task;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(prefix = "system.modules.TASK", name = "DefaultTask", havingValue = "true")
public class DefaultScheduledTasks implements ApplicationListener<ContextRefreshedEvent> { //这个为默认的定时任务调度器

    Logger logger = LoggerFactory.getLogger(DefaultScheduledTasks.class);

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        if (event.getApplicationContext().getParent() == null) {
            // 确保只在root application context启动时打印消息
            logger.info("默认任务调度器已经启动");
        }
    }

    // TODO: 实现你想要的定时任务
//    @Scheduled(cron = "0 00 22 * * ?")
//    public void task() { //定时任务( 每天 22:00:00 执行)
//        System.out.println("定时任务执行");
//    }


}
