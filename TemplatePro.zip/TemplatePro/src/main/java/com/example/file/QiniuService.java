package com.example.file;

import com.example.mq.config.RabbitMQTopicConfig;
import com.qiniu.common.QiniuException;
import com.qiniu.http.Response;
import com.qiniu.storage.UploadManager;
import com.qiniu.util.Auth;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Service
@ConditionalOnProperty(prefix = "system.modules.OSS", name = "qiNiuOSS", havingValue = "true") // 条件注解，只有当配置文件中system.modules.OSS.qiNiuOSS=true时，才会生效
public class QiniuService {

    @Autowired
    private UploadManager uploadManager;

    @Autowired
    private Auth auth;

    @Autowired
    private String upToken;

    @Value("${qiniu.domain}") // 外链域名
    private String domain;

    private static final Logger logger = LoggerFactory.getLogger(QiniuService.class);

    @PostConstruct
    public void init() {
        logger.info("七牛云服务正在启动...");
    }

    public String uploadFile(MultipartFile file) throws IOException {
        try {
            Response response = uploadManager.put(file.getBytes(), null, upToken);
            // 解析返回的key
            String key = response.jsonToMap().get("key").toString();
            // 构造完整的图片URL
            return domain + "/" + key;
        } catch (QiniuException e) {
            Response r = e.response;
            try {
                return r.bodyString();
            } catch (QiniuException e2) {
                // ignore
            }
        }
        return null;
    }


}