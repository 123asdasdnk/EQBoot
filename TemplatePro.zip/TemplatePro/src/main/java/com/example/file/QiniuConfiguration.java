package com.example.file;

import com.qiniu.storage.Region;
import com.qiniu.storage.UploadManager;
import com.qiniu.util.Auth;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConditionalOnProperty(prefix = "system.modules.OSS", name = "qiNiuOSS", havingValue = "true") // 条件注解，只有当配置文件中system.modules.OSS.qiNiuOSS=true时，才会生效
public class QiniuConfiguration {

    @Value("${qiniu.access-key}")
    private String accessKey;

    @Value("${qiniu.secret-key}")
    private String secretKey;

    @Value("${qiniu.bucket}")
    private String bucket;

    @Value("${qiniu.domain}") // 外链域名
    private String domain;

    private Logger logger = LoggerFactory.getLogger(QiniuConfiguration.class);
    @PostConstruct
    public void init() {
        logger.info("七牛云OSS已经配置初始化...");
    }

    @Bean
    public Auth auth() {
        return Auth.create(accessKey, secretKey);
    }

    @Bean
    public UploadManager uploadManager() {
        com.qiniu.storage.Configuration cfg = new com.qiniu.storage.Configuration(Region.autoRegion());
        return new UploadManager(cfg);
    }

    @Bean
    public String upToken(Auth auth) {
        return auth.uploadToken(bucket);
    }




}