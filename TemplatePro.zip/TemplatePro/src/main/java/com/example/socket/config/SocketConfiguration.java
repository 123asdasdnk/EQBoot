package com.example.socket.config;


import org.springframework.context.annotation.Configuration;

@Configuration
public class SocketConfiguration {
}
