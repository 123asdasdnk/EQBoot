package com.example.socket;

import org.springframework.stereotype.Component;

@Component
public class Server {
    // TODO
}
