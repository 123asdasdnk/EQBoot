package com.example.system;


import jakarta.annotation.PostConstruct;
import lombok.Data;
import net.sf.jsqlparser.statement.select.Top;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


@Data
@Component
public class SystemModuleService { //系统模块配置参数

    @Value("${system.modules.AOP}")
    public boolean AOP; //AOP模块方法监控

    @Value("${system.modules.MQ.RabbitMQ.HelloWorld}")
    public boolean HelloWorld; //RabbitMQ模块HelloWorld模式

    @Value("${system.modules.MQ.RabbitMQ.Topic}")
    public boolean Topic; //RabbitMQ模块Topic模式

    @Value("${system.modules.TASK.DefaultTask}")
    public boolean DefaultTask; //定时任务模块默认模式

    @Value("${system.modules.TASK.QuartzTask}")
    public boolean QuartzConfiguration; //定时任务模块Quartz模式

    @Value("${system.modules.OSS.qiNiuOSS}")
    public boolean qiNiuOSS; //七牛云模块配置参数

    private final Logger logger = LoggerFactory.getLogger(SystemModuleService.class);

    @PostConstruct
    public void init() {
        logger.info("系统模块配置参数初始化成功！");
    }






}
