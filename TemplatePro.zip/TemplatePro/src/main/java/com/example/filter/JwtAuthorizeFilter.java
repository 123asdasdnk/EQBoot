package com.example.filter;

import com.auth0.jwt.interfaces.DecodedJWT;
import com.example.utils.JwtUtils;
import jakarta.annotation.Resource;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;


//利用过滤器来实现，请求头的校验
@Component
public class JwtAuthorizeFilter extends OncePerRequestFilter {

    @Resource
    JwtUtils utils;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        String authorization = request.getHeader("Authorization"); //获取请求头里面的Authorization： （Bearer + jwt）
        DecodedJWT jwt = utils.resolveJwt(authorization);
        if(jwt != null){ //如果解析出来的jwt不为null,就进行验证，不然就往下走别的过滤链
            UserDetails user = utils.toUser(jwt);
            UsernamePasswordAuthenticationToken authentication = //实用Security内部的校验机制
                    new UsernamePasswordAuthenticationToken(user, null, user.getAuthorities());

            authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request)); //固定写法
            SecurityContextHolder.getContext().setAuthentication(authentication); //这里把验证信息让进去，表示已经验证过了
            request.setAttribute("id", utils.toId(jwt));
        }
        filterChain.doFilter(request, response);

    }
}
