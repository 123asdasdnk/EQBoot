//package com.example.config;
//
//import org.quartz.*;
//import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
///**
// * QuartzConfig 配置类用于配置Quartz调度器（要用就自己配，不用的话，就用系统自带(DefaultScheduler)的）
// */
//@Configuration
//@ConditionalOnProperty(prefix = "system.modules.TASK", name = "QuartzTask", havingValue = "true")
//public class QuartzConfiguration {
//    private static final Logger logger = LoggerFactory.getLogger(QuartzConfiguration.class);
//
//    /**
//     * 创建并启动Quartz调度器
//     *
//     * @return Scheduler对象
//     * @throws SchedulerException 调度器启动异常
//     */
//    @Bean
//    public Scheduler scheduler() throws SchedulerException {
//        // 创建默认的Quartz调度器
//        Scheduler scheduler = org.quartz.impl.StdSchedulerFactory.getDefaultScheduler();
//
//        // 启动调度器
//        scheduler.start();
//
//        // 记录日志，提示调度器已经正常运行
//        logger.info("Quartz定时器已经正常运行...");
//
//        // 返回Scheduler对象
//        return scheduler;
//    }
//
//
//}
