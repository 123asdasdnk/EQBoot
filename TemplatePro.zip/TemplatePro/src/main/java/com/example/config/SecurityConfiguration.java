package com.example.config;

import com.example.entity.RestBean;
import com.example.entity.dto.AccountDTO;
import com.example.entity.vo.response.AuthorizeRespVO;
import com.example.filter.JwtAuthorizeFilter;
import com.example.service.AccountService;
import com.example.utils.JwtUtils;
import jakarta.annotation.Resource;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.io.IOException;
import java.io.PrintWriter;

@Configuration
public class SecurityConfiguration {

    @Resource
    JwtUtils utils;

    @Resource
    JwtAuthorizeFilter jwtAuthorizeFilter;

    @Resource
    AccountService service;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http
                .authorizeHttpRequests(conf -> {  //配置http认证请求

                        conf.requestMatchers("/api/auth/**")
                                .permitAll() //关于验证的请求都可以通过
                                .anyRequest()
                                .authenticated(); //其它任何请求都要被验证
                })
                .formLogin(conf -> { //配置表单登录
                        conf.loginProcessingUrl("/api/auth/login") //登录处理url
                            .successHandler(this::onAuthenticationSuccess) //登录成功处理器
                            .failureHandler(this::onAuthenticationFailure); //登录失败处理器
                })
                .logout(conf -> {
                        conf.logoutUrl("/api/auth/logout") //退出登录处理url
                            .logoutSuccessHandler(this::onLogoutSuccess); //退出登录成功处理器
                })
                .exceptionHandling(conf -> {
                        conf.authenticationEntryPoint(this::onUnauthorized)
                            .accessDeniedHandler(this::onAccessDeny);

                })
                .cors(conf -> { //跨域配置
                    CorsConfiguration cors = new CorsConfiguration();

                    //添加前端站点地址，这样就可以告诉浏览器信任了,注意，要写localhost 和 127.0.0.1，
                    // 这个两个不太一样，为了方便都写(不然前端在不同的环境，比如vscode里面使用live server是127.0.0.1,在docker里面运行是localhost)
                    // 如果只写了一种，那么另一种还是会跨域
                    cors.addAllowedOrigin(WebConst.frontAddress);
                    cors.addAllowedOrigin(WebConst.frontLocalAddress); //如果不是本地的，这个就可以注释掉
                    //虽然也可以像这样允许所有 cors.addAllowedOriginPattern("*");
                    //但是这样并不安全，我们应该只许可给我们信任的站点

                    cors.setAllowCredentials(true);  //允许跨域请求中携带Cookie
                    cors.addAllowedHeader("*");   //其他的也可以配置，为了方便这里就 * 了
                    cors.addAllowedMethod("*");
                    cors.addExposedHeader("*");
                    UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
                    source.registerCorsConfiguration("/**", cors);  //直接针对于所有地址生效
                    conf.configurationSource(source);
                })
                .csrf(AbstractHttpConfigurer::disable) //csrf关了
                .sessionManagement( conf -> { //由于我们这里实用jwt了，用户信息会存储在jwt中，所以session不需要维护我们的用户信息的,所以要把sessionManagement变为无状态
                        conf.sessionCreationPolicy(SessionCreationPolicy.STATELESS); //session创建策略改为无状态
                })
                .addFilterBefore(jwtAuthorizeFilter, UsernamePasswordAuthenticationFilter.class)
                .build();
    }

    public void onUnauthorized(HttpServletRequest request,
                               HttpServletResponse response,
                               AuthenticationException exception) throws IOException {
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(RestBean.unauthorized(exception.getMessage()).asJsonString());
    }

    //登录了，但是没有权限
    public void onAccessDeny(HttpServletRequest request,
                       HttpServletResponse response,
                       AccessDeniedException exception) throws IOException {
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(RestBean.forbidden(exception.getMessage()).asJsonString());
    }

    //登录成功处理器
    public void onAuthenticationSuccess(HttpServletRequest request,
                                        HttpServletResponse response,
                                        Authentication authentication) throws IOException {
        response.setContentType("application/json;charset=utf-8");
        User user = (User)authentication.getPrincipal(); //获取登录的User (UserDetails)
        AccountDTO accountDTO = service.findAccountByNameOrEmail(user.getUsername());
        String token = utils.createJwt(user, accountDTO.getId(), accountDTO.getUsername()); //根据登录用户信息创建token
        AuthorizeRespVO vo = new AuthorizeRespVO();     //创建对应的VO对象
        vo.setExpire(utils.expireTime());       //设置过期时间
        vo.setRole(accountDTO.getRole());
        vo.setToken(token); //设置token
        vo.setUsername(accountDTO.getUsername()); //设置username
        response.getWriter().write(RestBean.success(vo).asJsonString()); //记得把vo返回
    }

    //登录失败处理器
    public void onAuthenticationFailure(HttpServletRequest request,
                                        HttpServletResponse response,
                                        AuthenticationException exception) throws IOException, ServletException {
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(RestBean.unauthorized(exception.getMessage()).asJsonString());
    }

    //退出登录成功处理器
    public void onLogoutSuccess(HttpServletRequest request,
                                HttpServletResponse response,
                                Authentication authentication) throws IOException, ServletException {
        response.setContentType("application/json;charset=utf-8");
        PrintWriter writer = response.getWriter();
        String authorization = request.getHeader("Authorization");
        if (utils.invalidateJwt(authorization)){
            writer.write(RestBean.success().asJsonString());
        } else {
            writer.write(RestBean.failure(400, "退出登录失败").asJsonString());
        }
    }

}
