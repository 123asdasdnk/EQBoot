package com.example.config;

public class WebConst { //web配置常量

    // 前端地址(要传入到跨域解决方法中)
    public final static String frontAddress = "http://127.0.0.1:5501";

    //本地开发环境，使用以下地址
    public final static String frontLocalAddress = "http://localhost:5501";

    // swagger相关路径，用于swagger-ui的访问，可以根据实际情况修改swagger地址
    public final static String[] swaggerPath = {"/swagger-ui/**"};

}
