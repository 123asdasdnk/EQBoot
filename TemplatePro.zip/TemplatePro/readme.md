# 项目说明
+ 本项目旨在，创建一个快速开发的框架，帮助开发者快速搭建基于SpringBoot + SpringSecurity + JWT +Mysql + RabbitMQ + Redis + Elasticsearch的Web应用。


## 项目目标

## 项目架构

